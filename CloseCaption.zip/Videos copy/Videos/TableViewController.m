//
//  TableViewController.m
//  VideoList
//
//  Created by Yahya  on 6/14/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "TableViewController.h"
#import "WebViewController.h"
#import "NiceController.h"
#import "TableViewCell.h"



@interface TableViewController ()
{
    //    NSMutableData *webData;
    //    NSURLConnection *connection;
    
    
    
    
    NSMutableData *data_for_first_connection;
    NSMutableData *data_for_second_connection;
    
    NSURLConnection *first_connection;
    NSURLConnection *second_connection;
    
    //NSMutableArray *jsonTitle;
    
    
    
    
    
    
    
    MPMoviePlayerViewController *player;
    
}

@end

@implementation TableViewController
@synthesize jsonTitle, jsonContent;


//
//- (void)awakeFromNib{
//    [super awakeFromNib];
//}
//

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [[self myTableView]setDelegate:self];
    [[self myTableView]setDataSource:self];
    
    //array = [[NSMutableArray alloc]init];
    
    jsonTitle = [[NSMutableArray alloc]init];
    jsonContent = [[NSMutableArray alloc]init];
    
    
    
    //PROCESSING FIRST CONNECTION
    NSURL *first_connection_url = [NSURL URLWithString:@"http://api.dvidshub.net/search?api_key=key-53ce7dc88f935&branch=Marines&page=1&max_results=50&thumb_width=600&type=video&tags_exclude=extra&sort=date&category"];
    NSURLRequest *first_connection_request = [NSURLRequest requestWithURL:first_connection_url];
    first_connection=[[NSURLConnection alloc]initWithRequest:first_connection_request delegate:self];
    
    
    
    
    if(first_connection)
    {
        data_for_first_connection = [[NSMutableData alloc] init];
    }
    
    
}




//methods to perform the connection and population of data

-(void)connection: (NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    if(connection==first_connection){
        data_for_first_connection = [[NSMutableData alloc]init];
    }
    else if(connection==second_connection){
        data_for_second_connection = [[NSMutableData alloc]init];
    }
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)thedata
{
    if(connection==first_connection){
        [data_for_first_connection appendData:thedata];
    }
    else if(connection==second_connection){
        [data_for_second_connection appendData:thedata];
    }
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //if data received network indicator not visible
    //[UIApplication sharedApplication].networkActivityIndicatorVisible=NO;
    
    if(connection==first_connection) {
        
        NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:data_for_first_connection options:0 error:nil];
        //NSDictionary *Gen =  [allDataDictionary objectForKey:@"genres"];
        NSArray *arrayOfResults = [allDataDictionary objectForKey:@"results"];
        
        
        //jsonTitle = [[NSMutableArray alloc] initWithCapacity:5];
        
            
            for(NSDictionary *diction in arrayOfResults){
                //NSDictionary *title = [diction objectForKey:@"title"];   //3
                
                NiceController *GetIt = [[NiceController alloc]init];
                //
                GetIt.myTitle = [diction objectForKey:@"title"];
                GetIt.Thumbnail = [diction objectForKey:@"thumbnail"];
                //GetIt.myIDs = [diction objectForKey:@"id"];
                
             
                    [jsonTitle addObject:GetIt];
                    
            
                
                NSString *ID = [diction objectForKey:@"id"];
                
                [jsonContent addObject:ID];
                
                 //[[self myTableView]reloadData];
            //}
        }
        
    }else if(connection == second_connection)
        
    {
        NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:data_for_second_connection options:0 error:nil];
        NSDictionary *results =  [allDataDictionary objectForKey:@"results"];
        
        // NiceController *PlayMe = [[NiceController alloc]init];
        
      
        
        
        NSArray *arrayOfFiles = [results objectForKey:@"files"];
        NSDictionary *closeCap =  [results objectForKey:@"closed_caption_urls"];

        
        
        //NSDictionary *dict = [arrayOfFiles objectAtIndex:0];
        if (arrayOfFiles != nil)
            
        {
            
            NSDictionary *diction = [arrayOfFiles objectAtIndex:0];
            
            NSString *SRC = [diction objectForKey:@"src"];

            
            NSLog(@"This is my url %@", SRC);
            
            
            
            // PlayMe.myTitle = [diction objectForKey:@"title"];
            
        
            NSURL *second_connection_url = [NSURL URLWithString:SRC];
            
            player = [[MPMoviePlayerViewController alloc] initWithContentURL:second_connection_url];
            [self presentMoviePlayerViewControllerAnimated:player];
            
        }
        
        
   
       // dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSLog(@"Downloading Started");
            //NSString *urlToDownloadS = @"http://api.dvidshub.net/closed-captions/get?asset_id=video:533041&format=srt&api_key=key-53ce7dc88f935.srt";
            

    
        NSString *SRT = [closeCap objectForKey:@"srt"];
        NSLog(@"This is srt: %@",SRT);

      
            NSURL  *urlS = [NSURL URLWithString:SRT];//1
            NSData *urlDataS = [NSData dataWithContentsOfURL:urlS];//1
            
            
            NSArray  *pathsS = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);//1
            
            NSString  *documentsDirectoryS = [pathsS objectAtIndex:0];//1
            
            NSString  *filePathS = [NSString stringWithFormat:@"%@/%@", documentsDirectoryS,@"filename.srt"];//1
            
            
            //NSLog(@"%@ This filename.srt", filePathS);
            
            
            //saving is done on main thread
            dispatch_async(dispatch_get_main_queue(), ^{
                [urlDataS writeToFile:filePathS atomically:YES];//1
                
                
                
                
                NSLog(@"File Saved !");
                
                
                
                [player.moviePlayer openSRTFileAtPath:filePathS
                                           completion:^(BOOL finished) {
                                               
                                               // Activate subtitles
                                               [player.moviePlayer showSubtitles];
                                               
                                               // Show video
                                               
                                               
                                               
                                           } failure:^(NSError *error) {
                                               
                                               NSLog(@"Error: %@", error.description);
                                               
                                           }];
            
                
                
            //});
            //[[self myTableView]reloadData];
        
         
        });
    //}
        
    
}

        
        
   // }
    [[self myTableView]reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //return 5;
    return [jsonTitle count];
    
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(!cell)
    {
        cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    //cell.textLabel.text = [jsonTitle objectAtIndex:indexPath.row];
    
    
    NiceController *Get = [jsonTitle objectAtIndex:indexPath.row];
    
    [cell setDetails:Get];
    
    
    return cell;
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    NSString *currentUrlsArr=[jsonContent objectAtIndex:indexPath.row];
    NSURL *second_connection_url = [NSURL URLWithString:currentUrlsArr];
    
    
    second_connection_url = [NSURL URLWithString:[NSString stringWithFormat:@"https://api.dvidshub.net/asset?id=%@&api_key=key-53ce7dc88f935",currentUrlsArr]];
    
    
    NSURLRequest *second_connection_request = [NSURLRequest requestWithURL:second_connection_url];
    second_connection=[[NSURLConnection alloc]initWithRequest:second_connection_request delegate:self];
    
    
    if(second_connection)
    {
        data_for_second_connection = [[NSMutableData alloc] init];
        
        
    }
    
    
}

//-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
//{
//    if([segue.identifier isEqualToString:@"detailSegue"]){
//        WebViewController *detail = segue.destinationViewController;
//        
//        
//        
//        NSIndexPath  *path = [self.myTableView indexPathForSelectedRow];
//        
//        
//        detail.great = [jsonTitle objectAtIndex:path.row];//jsonContent
//        detail.contentText = [jsonContent objectAtIndex:path.row];
//        
//        
//    }

//}



@end





