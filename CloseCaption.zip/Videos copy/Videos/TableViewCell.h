//
//  TableViewCell.h
//  VideoImage
//
//  Created by Yahya  on 6/22/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NiceController.h"


@interface TableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imageView1;

@property (strong, nonatomic) IBOutlet UILabel *title;
@property (strong, nonatomic) IBOutlet UILabel *myDescription;
@property (strong, nonatomic) IBOutlet UILabel *myDate;
@property (strong, nonatomic) IBOutlet UILabel *IDs;


@property(nonatomic, retain)NiceController *great;

//@property (strong, nonatomic) IBOutlet UILabel *recipeUrl;

-(void)setDetails:(NiceController *) new;



@end
