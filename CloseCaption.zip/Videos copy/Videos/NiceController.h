//
//  NiceController.h
//  NewsImages
//
//  Created by Yahya  on 6/26/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <Foundation/Foundation.h>

//#import <UIKit/UIKit.h>



@interface NiceController : NSObject

@property (nonatomic, copy)NSString *myTitle;
@property (nonatomic, copy)NSString *Thumbnail;
@property (nonatomic, copy)NSString *Describe;
@property (nonatomic, copy)NSString *Date;
//@property (nonatomic, copy)NSString *myIDs;


@property (nonatomic, retain) NSData *imageData;
//@property (nonatomic, retain) NSData *myIDs;

-(void)loadData;

@end
