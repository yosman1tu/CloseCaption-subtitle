//
//  MPMoviePlayerController+Subtitles.h
//  Videos
//
//  Created by Yahya  on 7/2/17.
//  Copyright © 2017 Towson University. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface MPMoviePlayerController (Subtitles)

#pragma mark - Methods
- (void)openWithSRTString:(NSString *)srtString completion:(void (^)(BOOL finished))success failure:(void (^)(NSError *error))failure;
- (void)openSRTFileAtPath:(NSString *)localFile completion:(void (^)(BOOL finished))success failure:(void (^)(NSError *error))failure;
- (void)showSubtitles;
- (void)hideSubtitles;

@property (nonatomic, assign) BOOL subtitleActivated;
@property (nonatomic, getter = isShowing) BOOL showing;

@end
