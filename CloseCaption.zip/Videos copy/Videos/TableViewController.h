//
//  TableViewController.h
//  VideoList
//
//  Created by Yahya  on 6/14/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import "MPMoviePlayerController+Subtitles.h"



@interface TableViewController : UITableViewController<UITableViewDataSource, UITableViewDelegate, NSURLConnectionDataDelegate>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;

@property(nonatomic, strong)NSMutableArray *jsonTitle;
@property(nonatomic, strong)NSMutableArray *jsonContent;





@end
