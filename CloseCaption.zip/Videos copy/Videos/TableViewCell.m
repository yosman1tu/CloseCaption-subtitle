//
//  TableViewCell.m
//  VideoImage
//
//  Created by Yahya  on 6/22/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell
@synthesize imageView1, title, myDescription, myDate, IDs;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

-(void)setDetails:(NiceController *) new
{
    title.text = new.myTitle;
    //IDs.text = new.myIDs;

    myDescription.text = new.Describe;
    //    myDescription.numberOfLines = 0;
    //    myDescription.lineBreakMode = NSLineBreakByWordWrapping;
    
    //myDate.text = new.Date;
    
    
    //    NSURL *url = [NSURL URLWithString:new.Thumbnail];
    //    NSData *imageData = [NSData dataWithContentsOfURL:url];
    
    if(new.imageData)
    {
        UIImage *image = [UIImage imageWithData:new.imageData];
        
        imageView1.image = image;
        
    }
    
    else
    {
        [new loadData];
        UIImage *image = [UIImage imageWithData:new.imageData];
        
        imageView1.image = image;
    }
    
    
    
}

@end
