//
//  NiceController.m
//  NewsImages
//
//  Created by Yahya  on 6/26/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "NiceController.h"

@implementation NiceController

@synthesize myTitle,Thumbnail,imageData; //myIDs;

-(void)loadData
{
    NSURL *url = [NSURL URLWithString:self.Thumbnail];
    //NSData *imageData = [[NSData alloc] initWithContentsOfURL:urlL];
    
    // NSLog(@"This is myUrl:", url);
    self.imageData = [NSData dataWithContentsOfURL:url];
   // self.myIDs = [NSData dataWithContentsOfURL:url];
    
}




@end
